# tagrefsorter

A CLI tool to normalize LaTeX `\tag{}` numbering in Jupyter Notebook (`.ipynb`) files.

## Installation

```bash
pip install tagrefsorter
```

## Usage

```bash
tagrefsorter path/to/notebook.ipynb
```

The notebook is overwritten in place.
